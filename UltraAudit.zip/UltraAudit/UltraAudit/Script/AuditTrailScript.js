﻿/*                    AuditTrailScript.js                       */
/*                  Written by: Sage Aucoin                     */
/*                        Jun 1st, 2016                         */

$(document).ready(function () {
    //timeout
    var t;
    window.onload = resetTimer;
    document.onmousemove = resetTimer;
    document.onkeypress = resetTimer;
    function logout() { window.location.replace("RedirectPage.html"); }
    function resetTimer() {
        clearTimeout(t);
        t = setTimeout(logout, 900000); //15 minutes = (1000 ms/s) * (60 s/m) * (15 m/1) 
    }

    //DatePicker Init
    var date = new Date();
    var startDate = new Date(date.getFullYear(), date.getMonth(), 1);
    $("#dpDateFrom").datepicker({ changeMonth: true, changeYear: true });
    $("#dpDateTo").datepicker({ changeMonth: true, changeYear: true });
    $("#dpDateFrom").datepicker("setDate", startDate);
    $("#dpDateTo").datepicker("setDate", new Date());
});

//Event handler that submits the form when user presses the enter key.
$(document).keypress(function (e) {
    var key = e.which;
    if (key === 13)  // the enter key code
    {
        $("input[name = btnSearch]").click();
        return false;
    }
});

function ClearFilters() {
    //Clear inputs in filter area
    $("#filterArea :input").val("");

    //Uncheck include user activities
    $("#cbUserActivities").attr("checked", false);
}

function SearchAudit(getPatientPortalAudit, getSchedulerAudit, getEhrAudit, patientId, orderId, postedBy, dateFrom, dateTo, getUserActivity, patientFirstName, patientLastName, activityType, dataType) {
    //Clean Inputs
    patientId           = cleanInput(patientId, false);
    patientFirstName    = cleanInput(patientFirstName, false);
    patientLastName     = cleanInput(patientLastName, false);
    activityType        = cleanInput(activityType, false);
    dataType            = cleanInput(dataType, false);
    orderId             = cleanInput(orderId, false);
    postedBy            = cleanInput(postedBy, false);
    dateFrom            = cleanInput(dateFrom, true);
    dateTo              = cleanInput(dateTo, true);

    //Validate Form
    if (!ValidateForm(getPatientPortalAudit, getSchedulerAudit, getEhrAudit, patientId, orderId, postedBy, dateFrom, dateTo)) {
        return false;
    }

    //Show loading screen
    $("#loadingScreen").show();
    $("form").animate({
        width: "1325px",
        height: "725px"
    });
    $("#filterArea").animate({
        width: "1000px"    
    });
    //Apply 'filters' and get data from backend
    $.ajax({
        type: "GET",
        url: "AuditView.aspx/SearchAudit",
        data: {
            "getPatientPortalAudit" : "\"" + getPatientPortalAudit + "\"",
            "getSchedulerAudit": "\"" + getSchedulerAudit + "\"",
            "getEhrAudit": "\"" + getEhrAudit + "\"",
            "patientId": "\"" + patientId + "\"",
            "orderId": "\"" + orderId + "\"",
            "postedBy": "\"" + postedBy + "\"",
            "dateFrom": "\"" + dateFrom + "\"",
            "dateTo": "\"" + dateTo + "\"",
            "getUserActivity": "\"" + getUserActivity + "\"",
            "patientFirstName": "\"" + patientFirstName + "\"",
            "patientLastName": "\"" + patientLastName + "\"",
            "activityType": "\"" + activityType + "\"",
            "dataType": "\"" + dataType + "\""
        },
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) { RemakeGrid(data); },
        error: function(data) {
            alert("There was an error during processing. Please refresh the page and try again. If the problem persists, then please contact support. " + data.d);
            //Hide Loading Screen
            $("#loadingScreen").fadeOut();
            //Hide grid
            $("#contentArea").hide();
            //Shrink area back to normal.
            $("form").animate({
                width: "850px",
                height: "400px"
            });
            $("#filterArea").animate({
                width: "800px"
            });
        }
    });
    return false;
}

function RemakeGrid(data) {
    //Hide loading screen
    $("#loadingScreen").fadeOut();
    //Show content area in case it was hidden during error script.
    $("#ContentArea").show();
    //reset grid
    try {
        jQuery("#jqGrid").jqGrid("clearGridData");
        jQuery("#jqGrid").jqGrid("setGridParam", { data: JSON.parse(data.d) });
        jQuery("#jqGrid").trigger("reloadGrid");
    } catch (e) {
        alert("There was an error reloading the grid. Please refresh the page and try again. If the problem persists, then please contact Support. " + e);
    }

    //Define templates for how data is shown in the grid. This makes the actual grid declaration cleaner
    var numberTemplate = { formatter: "text", align: "center", sorttype: "number" };
    var textTemplate = { formatter: "text", align: "center", sorttype: "text" };
    var dateTemplate = { align: "center", sorttype: "date", datefmt: "m/d/Y H:i A"};
    try {
    //Here's the moment we've all been waiting for. Fingers crossed
    $("#jqGrid")
        .jqGrid({
            datatype: "local",
            data: JSON.parse(data.d),
            colNames: ["Source Unique ID", "Date / Time", "Record #", "Patient Name","Description", "User Name", "Computer Name", "Audit Source", "Activity Type", "Data Type"],
            colModel: [
                { name: "UniqueId", index: "UniqueId", width: 125, template: numberTemplate },
                { name: "DateTimePosted", index: "DateTimePosted", width: 95, template: dateTemplate},
                { name: "PatientId", index: "PatientId", width: 90, template: textTemplate },
                { name: "PatientName", index: "PatientName", width: 100, template: textTemplate },
                { name: "AuditMessage", index: "AuditMessage", width: 175 },
                { name: "UserName", index: "UserName", width: 90, template: textTemplate },
                { name: "ComputerName", index: "ComputerName", width: 120, template: textTemplate },
                { name: "AuditSource", index: "AuditSource", width: 100, template: textTemplate },
                { name: "ActivityType", index: "ActivityType", width: 100, template: textTemplate },
                { name: "DataType", index: "DataType", width: 85, template: textTemplate }
            ],
            viewrecords: true,
            sortname: "DateTimePosted",
            sortorder: "desc",
            width: 1300,
            height: 300,
            rowNum: 25,
            rowList: [10, 25, 50, 100],
            pager: "#jqGridPager"
        });
    } catch (err) {
        alert("There was an error loading the grid. Please refresh the page and try again. If the problem persists, then please contact Support. " + err);
    }
}


function ValidateForm(patientPortalAudit, schedulerAudit, ehrAudit, uniqueid, orderId, Postedby, dateFrom, dateTo, userActivity) {
    //Check that at least one source of data is checked
    if (!patientPortalAudit && !schedulerAudit && !ehrAudit && !userActivity) { alert("Please select at least one audit source."); return false; }
    //check if either Date To or Date From is used but not both
    if ((!dateTo && dateFrom) || (dateTo && !dateFrom)) { alert("Please enter a value for both \"Date To\" and \"Date From\"."); return false; }
    //Check Date To for Valid Date
    if (!isDate(dateTo)) { alert("Please enter a valid date for \"Date To\""); return false; }
    //Check Date To for Valid Date
    if (!isDate(dateFrom)) { alert("Please enter a valid date for \"Date From\""); return false; }
    //Check that "Date to" is after "Date from". 
    if (dateTo < dateFrom) { alert("Please make sure that \"Date To\" is on or after \"Date From\"."); return false; }


    return true;
};

function cleanInput(s) {
    //Remove characters that break JSON.
    s = s.replace("\"", "");
    s = s.replace("&amp;", "");
    s = s.replace("&lt;", "");
    s = s.replace("&gt;", "");
    s = s.replace("\\", "");
    s = s.replace("--", "");
    s = s.replace(/[^a-zA-Z0-9-/_.]/g, "");
    return s;
}

function isDate(date) {
    return ( (!isNaN(new Date(date)) ));
}