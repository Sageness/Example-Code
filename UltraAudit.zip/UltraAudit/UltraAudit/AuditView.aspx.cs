﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using Newtonsoft.Json;
using UltraAudit.DAL;

namespace UltraAudit
{

    public partial class AuditView : System.Web.UI.Page
    {
        private static string _account = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Account validation
            //demoradiology -- ZGVtb3JhZGlvbG9neQ==
            //var acc = Request.QueryString["id"];
            //var accountFound = false;
            //if (!string.IsNullOrEmpty(Request.QueryString["id"]))
            //{
            //    byte[] data = Convert.FromBase64String(acc);
            //    _account = Encoding.UTF8.GetString(data);
            //    //Check if decoded Base 64 string is an actual valid account. 
            //    accountFound = new AuditTrailDal().CheckValidAccount(_account);
            //}
            //Redirect if valid account is not found
            //if (!accountFound)
            //{
            //    Response.Redirect("RedirectPage.html");
            //}
        }

        [WebMethod]
        [ScriptMethod(UseHttpGet = true, ResponseFormat = ResponseFormat.Json)]
        public static string SearchAudit(bool getPatientPortalAudit, bool getSchedulerAudit, bool getEhrAudit, string patientId, string orderId, string postedBy, string dateFrom, string dateTo, bool getUserActivity, string patientFirstName, string patientLastName, string activityType, string dataType)
        {
            //Sanitize inputs
            patientId           = Sanitize(patientId);
            patientFirstName    = Sanitize(patientFirstName);
            patientLastName     = Sanitize(patientLastName);
            activityType        = Sanitize(activityType);
            dataType            = Sanitize(dataType);
            postedBy            = Sanitize(postedBy);
            orderId             = Sanitize(orderId);
            dateFrom            = Sanitize(dateFrom);
            dateTo              = Sanitize(dateTo);

            //var ultraList = new AuditTrailDal().GetAuditList(getPatientPortalAudit, getEhrAudit, getSchedulerAudit, patientId, orderId, postedBy, dateFrom, dateTo, getUserActivity, patientFirstName, patientLastName, activityType, dataType, _account);

            //test data
            var ultraList = new List<Audit> {
            new Audit {UniqueId = "155", DateTimePosted = "04/20/2016 12:30:00", AuditMessage = "This is a test audit message0", UserName = "Sage.Aucoin", AuditSource = "Scheduler", PatientId = "12346", ComputerName = "192.168.100.83", PatientName = "Han Solo", ActivityType = "UPDATE", DataType = "Patient Chart"},
            new Audit {UniqueId = "156", DateTimePosted = "04/21/2016 02:30:00", AuditMessage = "This is a test audit message1", UserName = "glenn.weintraub", AuditSource = "EHR", PatientId = "vfdsv", ComputerName = "192.168.100.205", PatientName = "Princess Leia", ActivityType = "DELETE", DataType = "Billing" },
            new Audit {UniqueId = "157", DateTimePosted = "04/22/2016 08:30:00", AuditMessage = "This is a test audit message2", UserName = "alexey", AuditSource = "Scheduler", PatientId = "5245362_sadika", ComputerName = "Tazik", PatientName = "Luke Skywalker", ActivityType = "UPDATE", DataType = "Scheduler Calendar" },
            new Audit {UniqueId = "158", DateTimePosted = "04/23/2016 01:30:00", AuditMessage = "This is a test audit message3", UserName = "alexey", AuditSource = "Patient Portal", PatientId = "sadakl123", ComputerName = "Tazik", PatientName = "Anakin Skywalker", ActivityType = "UPDATE", DataType = "Patient Chart" },
            new Audit {UniqueId = "159", DateTimePosted = "04/24/2016 05:30:00", AuditMessage = "This is a test audit message4", UserName = "glenn.weintraub", AuditSource = "EHR", PatientId = "3498dnf", ComputerName = "192.168.100.205", PatientName = "Rey Skywalker", ActivityType = "DELETE", DataType = "Hx Information" },
            new Audit {UniqueId = "160", DateTimePosted = "04/25/2016 02:30:00", AuditMessage = "This is a test audit message5", UserName = "Sage.Aucoin", AuditSource = "EHR", PatientId = "glh27u", ComputerName = "192.168.100.83", PatientName = "Jar Jar Binks", ActivityType = "SEARCH", DataType = "" },
            new Audit {UniqueId = "161", DateTimePosted = "04/20/2016 11:30:00", AuditMessage = "This is a test audit message6", UserName = "Sage.Aucoin", AuditSource = "Scheduler", PatientId = "12346", ComputerName = "192.168.100.83", PatientName = "Han Solo", ActivityType = "UPDATE", DataType = "Patient Chart"},
            new Audit {UniqueId = "162", DateTimePosted = "04/21/2016 01:30:00", AuditMessage = "This is a test audit message7", UserName = "glenn.weintraub", AuditSource = "EHR", PatientId = "vfdsv", ComputerName = "192.168.100.205", PatientName = "Princess Leia", ActivityType = "DELETE", DataType = "Billing" },
            new Audit {UniqueId = "163", DateTimePosted = "04/22/2016 07:30:00", AuditMessage = "This is a test audit message8", UserName = "alexey", AuditSource = "Scheduler", PatientId = "5245362_sadika", ComputerName = "Tazik", PatientName = "Luke Skywalker", ActivityType = "UPDATE", DataType = "Scheduler Calendar" },
            new Audit {UniqueId = "164", DateTimePosted = "04/23/2016 01:00:00", AuditMessage = "This is a test audit message9", UserName = "alexey", AuditSource = "Patient Portal", PatientId = "sadakl123", ComputerName = "Tazik", PatientName = "Anakin Skywalker", ActivityType = "UPDATE", DataType = "Patient Chart" },
            new Audit {UniqueId = "165", DateTimePosted = "04/24/2016 04:30:00", AuditMessage = "This is a test audit message10", UserName = "glenn.weintraub", AuditSource = "EHR", PatientId = "3498dnf", ComputerName = "192.168.100.205", PatientName = "Rey Skywalker", ActivityType = "DELETE", DataType = "Hx Information" },
            new Audit {UniqueId = "166", DateTimePosted = "04/25/2016 01:30:00", AuditMessage = "This is a test audit message11", UserName = "Sage.Aucoin", AuditSource = "EHR", PatientId = "glh27u", ComputerName = "192.168.100.83", PatientName = "Jar Jar Binks", ActivityType = "SEARCH", DataType = "" }
            };

            return JsonConvert.SerializeObject(ultraList);
        }

        private static string Sanitize(string inputString)
        {
            //Check for script text
            inputString = inputString.ToLower().Replace("script", string.Empty);
            //Characters that break SQL
            inputString = inputString.ToLower().Replace("'", string.Empty);
            inputString = inputString.ToLower().Replace(";", string.Empty);
            inputString = inputString.ToLower().Replace("\"", string.Empty);
            
            return HttpUtility.HtmlEncode(inputString);
        }

        /// <summary>
        /// Audit class normalizes the data gathered from all three Audit Trails into a format that the front end grid can use.
        /// </summary>
        public class Audit
        {
            public string UniqueId = "";
            public string DateTimePosted = "";
            public string PatientId = "";
            public string AuditMessage = "";
            public string UserName = "";
            public string ComputerName = "";
            public string AuditSource = "";
            public string ActivityType = "";
            public string DataType = "";
            public string PatientName = "";
        }





    }
}