﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace UltraAudit.DAL
{
    public class AuditTrailDal
    {
        //////////////////////////////////////////////////////////////////////////
        ////////////////////// Ultra Omega Global variables //////////////////////
        //////////////////////////////////////////////////////////////////////////
        
        //////////////////  ORDER BY, UNION, AND WHERE CLAUSES  //////////////////
        //Order By
        private const string OrderBySql = @" ORDER BY Date DESC ";
        //PatientID
        private const string PatientIdSql = @" AND [MR Num] = @PatientID ";
        //Patient First Name
        private const string PatientFirstNameSql = @" AND [Patient First] LIKE @PatientFirstName + '%' ";
        //Patient Last Name
        private const string PatientLastNameSql = @" AND [Patient Last] LIKE @PatientLastName + '%' ";
        //Activity Type
        private const string ActivityTypeSql = @" AND ActionType LIKE '%' + @ActivityType + '%' ";
        //Data Type
        private const string DataTypeSql = @" AND EntityName LIKE '%' + @DataType + '%' ";
        //UniqueID
        private const string UniqueIdSql = @" AND CAST(SourceUniqueId AS NVARCHAR) = @UniqueID ";
        //PostedBy
        private const string PostedBySql = @" AND UserName LIKE '%' + @UserName + '%' ";
        //DateFrom and DateTo
        private const string DateSql = @" AND Date >= @DateFrom AND Date <= DATEADD(DAY, 1, @DateTo) ";
        //Union All
        private const string UnionAllSql = @" UNION ALL ";

        //////////////////////  INDIVIDUAL TABLE SQL  //////////////////////////
        //PatientPortal Audit Trail
        private const string GetPatientPortalSql = @"
SELECT TOP 20000
	a.Jobid AS UniqueID,
	a.Date AS Date,
	NULL AS ActivityType,
	NULL AS DataType,
	a.Audit AS AuditMessage,
	a.UserName AS UserName,
	'PatientPortal' AS AuditSource,
	pi.[MR Num] AS PatientID,
	pi.[Patient First] + ' ' + pi.[Patient Last] AS PatientName,
	a.ComputerName AS ComputerName
FROM Audit a
LEFT JOIN OrderSchedule os ON os.Jobid = a.Jobid
INNER JOIN PatientInfo pi ON os.PatientId = pi.[MR Num]
";

        //Scheduler Audit Trail
        private const string GetSchedulerSql = @"
SELECT TOP 20000
	CAST(sa.AppointmentID AS NVARCHAR(MAX)) AS UniqueID,
	sa.Date AS Date,
	sa.ActionType AS ActivityType,
	sa.EntityName AS DataType,
	sa.Audit AS AuditMessage,
	sa.UserName AS UserName,
	'Scheduler' AS AuditSource,
	pi.[MR Num] AS PatientID,
    pi.[Patient First] + ' ' + pi.[Patient Last] AS PatientName,
	sa.ComputerName AS ComputerName
FROM SchedulerAudit sa
INNER JOIN SchedulerResources sr ON sa.AppointmentID = sr.AppointmentID AND sr.ResourceType = 2
INNER JOIN PatientInfo pi ON sr.ResourceID = pi.AutoCount
";

        //EHR Audit Trail
        private const string GetEhrSql = @"
SELECT TOP 20000
    CAST(v.VisitId AS NVARCHAR) AS UniqueID,
	ve.Date AS Date,
	ve.ActionType AS ActivityType,
	ve.EntityName AS DataType,
    ve.Audit AS AuditMessage,
    ve.UserName AS UserName,
    'EHR' AS AuditSource,
    pi.[MR Num] AS PatientID,
    pi.[Patient First] + ' ' + pi.[Patient Last] AS PatientName,
    ve.ComputerName AS ComputerName
FROM VisitEHRAudit ve
INNER JOIN Visits v ON ve.VisitId = v.VisitId
INNER JOIN PatientInfo pi ON v.PatientId = pi.AutoCount
";

        //User Activity Log
        private const string GetUserActivitySql = @"
SELECT TOP 20000
	CAST(ua.Id AS NVARCHAR) AS UniqueID,
	ua.Date AS Date,
	NULL AS ActivityType,
	NULL AS DataType,
	ISNULL(uat.ActivityType, '') + ISNULL('; ' + comment.Description, '') AS AuditMessage,
	ua.UserId AS UserName,
	'User Activity Log' AS AuditSource,
	NULL AS PatientID,
	NULL AS PatientName,
	PC.Description AS ComputerName
FROM UserActivities ua
JOIN someDatabase.dbo.UserActivityTypes uat ON uat.Id = ua.UserActivityTypeId
LEFT JOIN someDatabase.dbo.UserActivityShortCuts PC ON PC.UserActivityShortCutTypeID = 1 AND ua.ShortCutComputerID = PC.ID
LEFT JOIN someDatabase.dbo.UserActivityShortCuts comment ON comment.UserActivityShortCutTypeID = 2 AND ua.ShortCutCommentID = comment.ID
";

        ////////    Filter Variables    ////////
        private static string _patientId = "";
        private static string _orderId = "";
        private static string _postedBy = "";
        private static string _patientFirstName = "";
        private static string _patientLastName = "";
        private static string _activityType = "";
        private static string _dataType = "";
        private static string _dateFrom = "";
        private static string _dateTo = "";

        /// <summary>
        /// This function builds and executes a SQL procedure using the filters received from the front end filters.
        /// </summary>
        public List<AuditView.Audit> GetAuditList(bool getPatientPortalAudit, bool getEhrAudit, bool getSchedulerAudit, string patientId, string orderId, string postedBy, string dateFrom, string dateTo, bool getUserActivities, string patientFirstName, string patientLastName, string activityType, string dataType, string account)
        {
            var auditList = new List<AuditView.Audit>();
            var sql = string.Empty;

            //Set Global Filter Variables
            _patientId = patientId;
            _orderId = orderId;
            _postedBy = postedBy;
            _patientFirstName = patientFirstName;
            _patientLastName = patientLastName;
            _activityType = activityType;
            _dataType = dataType;
            _dateFrom = dateFrom;
            _dateTo = dateTo;

            const string s = "s";   //scheduler
            const string a = "a";   //PatientPortal
            const string e = "e";   //ehr
            const string u = "u";   //user activity log

            //Figure out which sources to pull data from based on user selection
            //PatientPortal
            if (getPatientPortalAudit) { sql = GetPatientPortalSql + FilterSql(a); }
            //Scheduler
            if (getSchedulerAudit && string.IsNullOrEmpty(sql)) { sql = GetSchedulerSql + FilterSql(s); }
            else if (getSchedulerAudit && !string.IsNullOrEmpty(sql)) { sql = sql + UnionAllSql + GetSchedulerSql + FilterSql(s); }
            //EHR
            if (getEhrAudit && string.IsNullOrEmpty(sql)) { sql = GetEhrSql + FilterSql(e); }
            else if (getEhrAudit && !string.IsNullOrEmpty(sql)) { sql = sql + UnionAllSql + GetEhrSql + FilterSql(e); }
            //User Activity Log
            if (getUserActivities && string.IsNullOrEmpty(sql)) { sql = GetUserActivitySql + FilterSql(u); }
            else if (getUserActivities && !string.IsNullOrEmpty(sql)) { sql = sql + UnionAllSql + GetUserActivitySql + FilterSql(u); }
 
            //Add order by
            sql += OrderBySql;

            //Get connection string from config
            var connString = ConfigurationManager.AppSettings["generalConnectionString"] + "database=" + account;
            using(var conn = new SqlConnection(connString))
            { 
                //Open connection. Gets automagically closed later.
                conn.Open();
                using (var sCmd = new SqlCommand(sql, conn))
                {
                    //Add sql parameters
                    sCmd.Parameters.AddWithValue("@UniqueID", orderId);
                    sCmd.Parameters.AddWithValue("@patientID", patientId);
                    sCmd.Parameters.AddWithValue("@PatientFirstName", patientFirstName);
                    sCmd.Parameters.AddWithValue("@PatientLastName", patientLastName);
                    sCmd.Parameters.AddWithValue("@ActivityType", activityType);
                    sCmd.Parameters.AddWithValue("@DataType", dataType);
                    sCmd.Parameters.AddWithValue("@UserName", postedBy);
                    sCmd.Parameters.AddWithValue("@DateFrom", dateFrom);
                    sCmd.Parameters.AddWithValue("@DateTo", dateTo);
                    try
                    {
                        using (var dr = sCmd.ExecuteReader())
                        {
                            //Read executed SQL
                            while (dr.Read())
                            {
                                //Build list of audit records.
                                var res = new AuditView.Audit
                                {
                                    UniqueId = dr["UniqueID"] is DBNull ? "" : (string)dr["UniqueID"],
                                    DateTimePosted = dr["Date"] is DBNull ? "" : ((DateTime)dr["Date"]).ToString(),
                                    AuditMessage = dr["AuditMessage"] is DBNull ? "" : (string)dr["AuditMessage"],
                                    UserName = dr["UserName"] is DBNull ? "" : (string)dr["UserName"],
                                    AuditSource = dr["AuditSource"] is DBNull ? "" : (string)dr["AuditSource"],
                                    PatientId = dr["PatientId"] is DBNull ? "" : (string)dr["PatientId"],
                                    ComputerName = dr["ComputerName"] is DBNull ? "" : (string)dr["ComputerName"],
                                    ActivityType = dr["ActivityType"] is DBNull ? "" : (string)dr["ActivityType"],
                                    DataType = dr["DataType"] is DBNull ? "" : (string)dr["DataType"],
                                    PatientName = dr["PatientName"] is DBNull ? "" : (string)dr["PatientName"]
                                };
                                auditList.Add(res);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    
                }
            }
            return auditList;
        }

        /// <summary>
        /// Because of the nature of how the audit tables are structures, we need to handle the WHERE clauses dynamically. 
        /// This function checks when table it needs to build the WHERE clause for and does so accordingly for each filter from the front end.
        /// </summary>
        private static string FilterSql(string source)
        {
            const string t = "SourceUniqueId";      //UniqueID Placeholder
            const string a = "os.Jobid";            //UniqueID for PatientPortal Audit
            const string s = "sa.AppointmentId";    //UniqueID for Scheduler Audit
            const string e = "v.VisitId";           //UniqueID for EHR Audit
            const string u = "ua.Id";               //UniqueID for User Activity
            
            //Add default line so that we can just add "AND..." clauses. 
            var filterSql = @"WHERE 1=1 ";

            //Build filters
            //PatientID (Record #) Filter (Not used by user activity so omit from there)
            if (!string.IsNullOrEmpty(_patientId) && (source.ToLower() != "u")) { filterSql += PatientIdSql; }

            //Posted by (Username) Filter
            if (!string.IsNullOrEmpty(_postedBy))
            {
                //User Activity uses "UserId" instead of "UserName". 
                if (source.ToLower() == "u") { filterSql += PostedBySql.Replace(" UserName", " UserId"); }
                else { filterSql += PostedBySql; }
            }

            //Date Filter
            if (!string.IsNullOrEmpty(_dateFrom) && !string.IsNullOrEmpty(_dateTo))
            {
                filterSql += DateSql;
            }

            //Unique ID Filter
            if (!string.IsNullOrEmpty(_orderId))
            {
                switch (source.ToLower())
                {
                    case "a": filterSql += UniqueIdSql.Replace(t,a); break;
                    case "s": filterSql += UniqueIdSql.Replace(t,s); break;
                    case "e": filterSql += UniqueIdSql.Replace(t,e); break;
                    case "u": filterSql += UniqueIdSql.Replace(t,u); break;
                    default: filterSql += UniqueIdSql; break;
                }
            }

            //Patient First Name Filter (Not used by user activity so omit from there)
            if (!string.IsNullOrEmpty(_patientFirstName) && (source.ToLower() != "u")) { filterSql += PatientFirstNameSql; }
            
            //Patient Last Name Filter (Not used by user activity so omit from there)
            if (!string.IsNullOrEmpty(_patientLastName) && (source.ToLower() != "u")) { filterSql += PatientLastNameSql; }

            //Activity Type Filter (Not used by Audit or User Activity Log, so omit from those)
            if (!string.IsNullOrEmpty(_activityType) && source.ToLower() != "u" && source.ToLower() != "a") { filterSql += ActivityTypeSql; }

            //Data Type Filter (Not used by Audit or User Activity Log, so omit from those)
            if (!string.IsNullOrEmpty(_dataType) && source.ToLower() != "u" && source.ToLower() != "a") { filterSql += DataTypeSql; }

            return filterSql;
        }

        public bool CheckValidAccount(string account)
        {
            var accountFound = false;
            var connString = ConfigurationManager.AppSettings["globalConnectionString"];
            var sql = @"SELECT COUNT(*) FROM someDatabase.dbo.Accounts a WHERE a.AccountId = @Account AND a.Active = 1";

            using (var conn = new SqlConnection(connString))
            {
                conn.Open();
                using (var sCmd = new SqlCommand(sql, conn))
                {
                    //Add sql parameter
                    sCmd.Parameters.AddWithValue("@Account", account);
                    var count = (int) sCmd.ExecuteScalar();
                    if (count > 0) { accountFound = true; }
                }
            }
            return accountFound;
        }
    }
}